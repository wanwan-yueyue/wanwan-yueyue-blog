#ifndef __KEY_H__
#define __KEY_H__

/**
 * 功能：获取独立按键键值
 * 返回：1-4（对应K1-K4），无按键按下返回0
 */
unsigned char Key();

#endif