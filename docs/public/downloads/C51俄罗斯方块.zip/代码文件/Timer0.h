#ifndef __TIMER0_H__
#define __TIMER0_H__

/*
函数：Timer0Init
功能：定时器0初始化
输入：无
输出：无
*/
void Timer0Init(void);//1毫秒@11.0592MHz

#endif