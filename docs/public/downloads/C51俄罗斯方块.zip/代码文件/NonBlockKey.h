// NonBlockKey.h
#ifndef __NON_BLOCK_KEY_H__
#define __NON_BLOCK_KEY_H__

unsigned char NonBlockKey_GetKey(void);
void NonBlockKey_Scan(void);

#endif